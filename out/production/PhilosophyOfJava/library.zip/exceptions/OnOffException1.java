//: exceptions/OnOffException1.java
public class OnOffException1 extends Exception {} ///:~
