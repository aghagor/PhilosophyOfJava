//: exceptions/OnOffException2.java
public class OnOffException2 extends Exception {} ///:~
